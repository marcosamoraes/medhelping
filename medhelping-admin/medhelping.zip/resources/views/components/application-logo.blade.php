<img src="{{ asset('images/logo.png') }}" alt="" {{ $attributes }} />
